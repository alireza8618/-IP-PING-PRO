package com.example.ippingpro;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(7, 12, 9), PANEL = Color.rgb(16, 25, 19), GREEN = Color.rgb(57, 255, 136), MUTED = Color.rgb(145, 164, 151);
    private EditText hostInput;
    private TextView pingValue, status, minValue, maxValue, avgValue, lossValue, log;
    private Button startButton;
    private volatile boolean running = false;
    private Thread worker;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private long min = Long.MAX_VALUE, max = 0, total = 0;
    private int success = 0, failed = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(22), dp(22), dp(22), dp(24));
        scroll.addView(root); setContentView(scroll);

        TextView brand = text("●  IP PING PRO", 22, GREEN, true); root.addView(brand);
        TextView sub = text("NETWORK DIAGNOSTICS  /  LIVE MONITOR", 10, MUTED, true); sub.setPadding(0, dp(7), 0, dp(22)); root.addView(sub);

        LinearLayout inputCard = card(); root.addView(inputCard);
        inputCard.addView(text("آدرس IP یا دامنه", 14, Color.WHITE, true));
        hostInput = new EditText(this); hostInput.setSingleLine(true); hostInput.setText("1.1.1.1"); hostInput.setTextColor(Color.WHITE); hostInput.setHintTextColor(MUTED); hostInput.setHint("مثلاً 8.8.8.8 یا google.com"); hostInput.setInputType(InputType.TYPE_CLASS_TEXT);
        hostInput.setPadding(dp(12), 0, dp(12), 0); hostInput.setBackground(shape(Color.rgb(8,14,10), GREEN, 1));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, dp(52)); ip.topMargin = dp(12); inputCard.addView(hostInput, ip);
        startButton = new Button(this); startButton.setText("شروع تست  ▶"); startButton.setTextColor(Color.BLACK); startButton.setAllCaps(false); startButton.setTextSize(15); startButton.setTypeface(null, Typeface.BOLD); startButton.setBackground(shape(GREEN, GREEN, 0));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(50)); bp.topMargin = dp(12); inputCard.addView(startButton, bp);

        LinearLayout live = card(); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(172)); lp.topMargin = dp(16); root.addView(live, lp);
        live.addView(text("PING فعلی", 12, MUTED, true));
        pingValue = text("—", 54, GREEN, true); pingValue.setGravity(Gravity.CENTER); live.addView(pingValue, new LinearLayout.LayoutParams(-1, 0, 1));
        status = text("آماده تست", 12, MUTED, false); status.setGravity(Gravity.CENTER); live.addView(status);

        TextView statsTitle = text("آمار اتصال", 16, Color.WHITE, true); statsTitle.setPadding(0, dp(22), 0, dp(10)); root.addView(statsTitle);
        LinearLayout row1 = new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL); root.addView(row1);
        minValue = addStat(row1, "کمترین", "—"); maxValue = addStat(row1, "بیشترین", "—");
        LinearLayout row2 = new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL); LinearLayout.LayoutParams r2 = new LinearLayout.LayoutParams(-1, -2); r2.topMargin=dp(10); root.addView(row2);
        avgValue = addStat(row2, "میانگین", "—"); lossValue = addStat(row2, "Packet Loss", "0%");

        TextView logTitle = text("گزارش تست", 15, Color.WHITE, true); logTitle.setPadding(0, dp(22), 0, dp(8)); root.addView(logTitle);
        log = text("هنوز تستی اجرا نشده است.", 12, MUTED, false); log.setPadding(dp(14), dp(14), dp(14), dp(14)); log.setBackground(shape(PANEL, PANEL, 0)); root.addView(log);
        TextView note = text("نکته: بعضی سرورها پاسخ ICMP را مسدود می‌کنند؛ در این حالت ممکن است پینگ ناموفق دیده شود.", 11, MUTED, false); note.setPadding(0, dp(16), 0, 0); root.addView(note);

        startButton.setOnClickListener(v -> { if (running) stopTest(); else startTest(); });
    }

    private void startTest() {
        String host = hostInput.getText().toString().trim();
        if (host.isEmpty() || host.contains(" ")) { status.setText("آدرس معتبر وارد کنید"); return; }
        resetStats(); running = true; hostInput.setEnabled(false); startButton.setText("توقف تست  ■"); status.setText("در حال بررسی " + host); log.setText("شروع تست برای " + host + "\n");
        worker = new Thread(() -> {
            while (running) {
                long start = System.nanoTime(); boolean ok = false; long ms = -1; String line;
                try {
                    Process p = new ProcessBuilder("ping", "-c", "1", "-W", "2", host).redirectErrorStream(true).start();
                    BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream())); String s; String output="";
                    while ((s=br.readLine())!=null) output += s + "\n";
                    int code = p.waitFor();
                    Matcher m = Pattern.compile("time[=<]([0-9.]+)").matcher(output);
                    if (code == 0 && m.find()) { ms = Math.max(0, Math.round(Double.parseDouble(m.group(1)))); ok=true; }
                } catch (Exception ignored) { }
                if (ok) { success++; total += ms; min=Math.min(min,ms); max=Math.max(max,ms); line="پاسخ: " + ms + " ms"; }
                else { failed++; line="بدون پاسخ / Timeout"; }
                final boolean good=ok; final long value=ms; final String msg=line;
                runOnUiThread(() -> updateUi(good, value, msg));
                try { Thread.sleep(1000); } catch (InterruptedException e) { break; }
            }
        }); worker.start();
    }
    private void updateUi(boolean ok, long ms, String msg) {
        if (ok) pingValue.setText(ms + " ms"); else pingValue.setText("TIMEOUT");
        pingValue.setTextColor(ok ? GREEN : Color.rgb(255,90,90)); status.setText(ok ? "● اتصال برقرار است" : "● پاسخی دریافت نشد"); status.setTextColor(ok ? GREEN : Color.rgb(255,110,110));
        minValue.setText(min==Long.MAX_VALUE?"—":min+" ms"); maxValue.setText(max==0?"—":max+" ms"); avgValue.setText(success==0?"—":(total/success)+" ms");
        int all=success+failed; lossValue.setText(all==0?"0%":String.format(Locale.US,"%.0f%%",failed*100.0/all));
        String old=log.getText().toString(); log.setText(msg + "\n" + old); if (log.length()>1800) log.setText(log.getText().subSequence(0,1800));
    }
    private void stopTest() { running=false; if(worker!=null) worker.interrupt(); hostInput.setEnabled(true); startButton.setText("شروع تست  ▶"); status.setText("تست متوقف شد"); status.setTextColor(MUTED); }
    private void resetStats(){ min=Long.MAX_VALUE; max=0; total=0; success=0; failed=0; pingValue.setText("—"); pingValue.setTextColor(GREEN); minValue.setText("—"); maxValue.setText("—"); avgValue.setText("—"); lossValue.setText("0%"); }
    private TextView addStat(LinearLayout row,String label,String value){ LinearLayout c=card(); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(82),1); p.setMargins(0,0,dp(8),0); row.addView(c,p); c.addView(text(label,11,MUTED,true)); TextView v=text(value,19,GREEN,true); v.setPadding(0,dp(8),0,0); c.addView(v); return v; }
    private LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(dp(15),dp(14),dp(15),dp(14)); l.setBackground(shape(PANEL,PANEL,0)); return l; }
    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); return t; }
    private GradientDrawable shape(int color,int stroke,int width){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(14)); if(width>0)d.setStroke(dp(width),stroke); return d; }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onDestroy(){ running=false; executor.shutdownNow(); super.onDestroy(); }
}
